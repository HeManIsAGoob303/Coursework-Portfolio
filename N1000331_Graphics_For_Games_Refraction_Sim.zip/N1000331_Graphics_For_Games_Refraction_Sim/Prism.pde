class SimPrism extends Sim3DObject {

  PVector[] vertices;
  
  float refractiveIndex;
  color fillColour;

  public SimPrism() {
    setDimensions(1, 1, 1);
    this.fillColour = color(150, 200, 255, 200);
    this.refractiveIndex = 1.5;
  }

  public SimPrism(float w, float h, float d, color c, float index) {
    setDimensions(w, h, d);
    this.fillColour = c;
    this.refractiveIndex = index;
  }

  void setDimensions(float w, float h, float d) {
    float halfW = w / 2;
    float halfH = h / 2;
    float halfD = d / 2;

    vertices = new PVector[6];

    vertices[0] = new PVector(0, halfH, halfD); // Top front peak
    vertices[1] = new PVector(-halfW, -halfH, halfD); // Bottom front left
    vertices[2] = new PVector(halfW, -halfH, halfD); // Bottom front right
    
    vertices[3] = new PVector(0, halfH, -halfD); // Top back peak
    vertices[4] = new PVector(-halfW, -halfH, -halfD); // Bottom back left
    vertices[5] = new PVector(halfW, -halfH, -halfD); // Bottom back right
    
  }

  SimExtents getTransformedExtents() {
    return new SimExtents(transformVertices(vertices));
  }

  SimTriangle[] getTransformedTriangles() {
    PVector[] tv = transformVertices(vertices);
    
    SimTriangle[] tri = new SimTriangle[8];
    
    tri[0] = new SimTriangle(tv[0], tv[1], tv[2]);
    
    tri[1] = new SimTriangle(tv[3], tv[5], tv[4]);
    
    tri[2] = new SimTriangle(tv[0], tv[3], tv[4]);
    tri[3] = new SimTriangle(tv[0], tv[4], tv[1]);
    
    tri[4] = new SimTriangle(tv[0], tv[2], tv[5]);
    tri[5] = new SimTriangle(tv[0], tv[5], tv[3]);
    
    tri[6] = new SimTriangle(tv[1], tv[4], tv[5]);
    tri[7] = new SimTriangle(tv[1], tv[5], tv[2]);
    
    return tri;
  }

  public void drawMe() {
    pushStyle();
    
    fill(fillColour);
    stroke(255, 50);
    
    beginShape();
    drawTransformedVertex(vertices[0]);
    drawTransformedVertex(vertices[1]);
    drawTransformedVertex(vertices[2]);
    endShape(CLOSE);
    
    beginShape();
    drawTransformedVertex(vertices[3]);
    drawTransformedVertex(vertices[5]);
    drawTransformedVertex(vertices[4]);
    endShape(CLOSE);
    
    beginShape();
    drawTransformedVertex(vertices[0]);
    drawTransformedVertex(vertices[3]);
    drawTransformedVertex(vertices[4]);
    drawTransformedVertex(vertices[1]);
    endShape(CLOSE);
    
    beginShape();
    drawTransformedVertex(vertices[0]);
    drawTransformedVertex(vertices[2]);
    drawTransformedVertex(vertices[5]);
    drawTransformedVertex(vertices[3]);
    endShape(CLOSE);
    
    beginShape();
    drawTransformedVertex(vertices[1]);
    drawTransformedVertex(vertices[4]);
    drawTransformedVertex(vertices[5]);
    drawTransformedVertex(vertices[2]);
    endShape(CLOSE);
    
    popStyle();
  }
  
  void setFillColour(color c) {
    this.fillColour = c;
  }
}
