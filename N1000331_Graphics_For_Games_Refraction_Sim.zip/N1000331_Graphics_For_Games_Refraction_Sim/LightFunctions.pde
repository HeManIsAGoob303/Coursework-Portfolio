
// Determine wave colour by wavelength
public color findWavelengthColour(float wavelength) {

  if (wavelength >= 650.0) {
    return color(255, 0, 0);
  } else if (wavelength >= 600) {
    return color(225, 165, 0);
  } else if (wavelength >= 580) {
    return color(255, 255, 0);
  } else if (wavelength >= 550) {
    return color(0, 255, 0);
  } else if (wavelength >= 500) {
    return color(0, 255, 255);
  } else if (wavelength >= 450) {
    return color(0, 0, 255);
  } else if (wavelength >= 400) {
    return color(127, 0, 255);
  }

  return color(255, 255, 255);
}

// Calculate IOR by colour wavelength using Cauchy's equation - n(λ) = A + (B / λ^2)
public float calculateIORByWavelength(float coefficientA, float coefficientB, float wavelengthNm) {

  float wavelengthUm = wavelengthNm / 1000.0;

  float IOR = coefficientA + (coefficientB / sq(wavelengthUm));

  return IOR;
}

class Photon {
  PVector pos;
  PVector dir;
  float speed = 50.0;
  float wavelength;
  color c;

  boolean hasHitObject = false;
  
  boolean hasExitedPrism = false;

  ArrayList<PVector> whiteLight;
  ArrayList<PVector> trail;
  SimSphere sphereBody;

  Photon (PVector startPos, PVector startDir, float lambda) {
    pos = startPos.copy();
    dir = startDir.copy().normalize();
    wavelength = lambda;

    c = findWavelengthColour(wavelength);

    whiteLight = new ArrayList<PVector>();
    whiteLight.add(pos.copy());

    trail = new ArrayList<PVector>();

    sphereBody = new SimSphere(2);
  }

  void update() {
    pos.add(PVector.mult(dir, speed));
  }

  void render() {

    if (whiteLight.size() > 0) {
      pushStyle();
      stroke(255);
      strokeWeight(4);
      noFill();
      beginShape(LINE_STRIP);
      for (PVector p : whiteLight) {
        vertex(p.x, p.y, p.z);
      }

      if (!hasHitObject) {
        vertex(pos.x, pos.y, pos.z);
      }
      endShape();
      popStyle();
    }

    color drawColour = hasHitObject ? c : color(255);

    if (trail.size() > 0) {
      pushStyle();
      stroke(drawColour);
      strokeWeight(4);
      noFill();
      beginShape(LINE_STRIP);
      for (PVector p : trail) {
        vertex(p.x, p.y, p.z);
      }
      vertex(pos.x, pos.y, pos.z);
      endShape();
      popStyle();
    }

    //if (speed > 0) {
    pushStyle();
    fill(drawColour);
    noStroke();
    sphereBody.setTranslation(pos);
    sphereBody.drawMe();
    popStyle();
    //}
  }

  public void refract(PVector normal, float n1, float n2) {

    dir.normalize();

    normal.normalize();

    float eta = n1 / n2;

    float cosInc = PVector.dot(dir, normal);

    PVector n = normal.copy();

    if (cosInc > 0) {
      n.mult(-1);
      //eta = n2 / n1;
    } else {
      cosInc = -cosInc;
    }

    float sin2Ref = eta * eta * (1.0 - cosInc * cosInc);

    float k = 1.0 - sin2Ref;

    PVector result = new PVector();

    if (k < 0) {
      float dotIncomingNormal = PVector.dot(dir, n);
      result = PVector.sub(dir, PVector.mult(n, 2 * dotIncomingNormal));
    } else {
      PVector t1 = PVector.mult(dir, eta);
      PVector t2 = PVector.mult(n, (eta * cosInc) - sqrt(k));
      result = PVector.add(t1, t2);
    }

    result.normalize();
    dir = result;
  }
}

class Impact {
  PVector pos;
  color c;

  Impact(PVector pos, color c) {
    this.pos = pos.copy();
    this.c = c;
  }

  void drawMe() {
    pushStyle();
    pushMatrix();
    fill(c);
    noStroke();
    translate(pos.x, pos.y, pos.z);
    sphere(20);
    popMatrix();
    popStyle();
  }
}
