class SimLens extends Sim3DObject {

  PVector[] vertices;

  float radiusOfCurvature;
  float diameter;
  float thickness;

  float refractiveIndex;

  PVector frontCentre;
  PVector backCentre;

  int rings; // latitude lines
  int segments; // longitude lines

  color fillColour;

  public SimLens() {
    this.radiusOfCurvature = 300.0;
    this.diameter = 200.0;
    this.thickness = 50.0;
    this.refractiveIndex = 1.5;
    this.rings = 10;
    this.segments = 16;
    this.fillColour = color(150, 200, 255, 150);
    setIdentityTransform();
    buildGeometry();
  }

  SimLens(float r, float d, float t, color c, float index) {
    this.radiusOfCurvature = r;
    this.diameter = d;
    this.thickness = t;
    this.fillColour = c;
    this.refractiveIndex = index;
    this.rings = 12;
    this.segments = 20;
    setIdentityTransform();
    buildGeometry();
  }

  void buildGeometry() {
    float halfD = diameter * 0.5;

    // Stop radius from being too tight
    if (abs(radiusOfCurvature) < halfD * 1.01) {
      radiusOfCurvature = (radiusOfCurvature > 0 ? 1 : -1) * halfD * 1.01;
    }

    float r = radiusOfCurvature;
    float absR = abs(r);
    float sag = absR - sqrt(sq(absR) - sq(halfD));

    float tempThickness = thickness;

    // Stop convex lens overlapping
    if (r > 0) {
      tempThickness = max(thickness, sag * 2.0 + 2.0);
    } else {
      tempThickness = max(thickness, 2.0);
    }

    // Set sphere centres
    if (r > 0) {
      frontCentre = new PVector(0, 0, (tempThickness * 0.5) - absR);
      backCentre = new PVector(0, 0, -(tempThickness * 0.5) + absR);
    } else {
      frontCentre = new PVector(0, 0, (tempThickness * 0.5) + absR);
      backCentre = new PVector(0, 0, -(tempThickness * 0.5) - absR);
    }
    
    float capAngle = asin(halfD / absR);
    int verts = (rings + 1) * (segments + 1);
    vertices = new PVector[verts * 2];
    
    for (int ring = 0; ring <= rings; ring++) {
      float phi = capAngle * (ring / (float) rings);
      float sinPhi = sin(phi);
      float cosPhi = cos(phi);
      
      for (int segment = 0; segment <= segments; segment++) {
        float theta = TWO_PI * (segment / (float) segments);
        
        float x = absR * sinPhi * cos(theta);
        float y = absR * sinPhi * sin(theta);
        
        float zOffset = absR * cosPhi - absR;
        
        float frontZ = (tempThickness * 0.5) + (r > 0 ? zOffset : -zOffset);
        float backZ = -(tempThickness * 0.5) - (r > 0 ? zOffset : -zOffset);
        
        int indexFront = ring * (segments + 1) + segment;
        int indexBack = verts + indexFront;
        
        vertices[indexFront] = new PVector(x, y, frontZ);
        vertices[indexBack] = new PVector(x, y, backZ);
      }
    }
  }

  SimTriangle[] getTransformedTriangles() {
    PVector[] tv = transformVertices(vertices);

    int faceVerts = (rings + 1) * (segments + 1);
    int faceTris = rings * segments * 2;
    int rimTris = segments * 2;

    SimTriangle[] tri = new SimTriangle[faceTris * 2 + rimTris];

    int triIndex = 0;

    for (int ring = 0; ring < rings; ring++) {
      for (int segment = 0; segment < segments; segment++) {

        // front cap
        int frontIndexCurrent = ring * (segments + 1) + segment;
        int frontIndexNext = (ring + 1) * (segments + 1) + segment;

        PVector topLeftFront = tv[frontIndexCurrent];
        PVector topRightFront = tv[frontIndexCurrent + 1];
        PVector bottomLeftFront = tv[frontIndexNext];
        PVector bottomRightFront = tv[frontIndexNext + 1];

        tri[triIndex++] = new SimTriangle(topLeftFront, bottomLeftFront, bottomRightFront);
        tri[triIndex++] = new SimTriangle(topLeftFront, bottomRightFront, topRightFront);

        // back cap
        int backIndexCurrent = faceVerts + frontIndexCurrent;
        int backIndexNext = faceVerts + frontIndexNext;

        PVector topLeftBack = tv[backIndexCurrent];
        PVector topRightBack = tv[backIndexCurrent + 1];
        PVector bottomLeftBack = tv[backIndexNext];
        PVector bottomRightBack = tv[backIndexNext + 1];

        tri[triIndex++] = new SimTriangle(topLeftBack, bottomRightBack, bottomLeftBack);
        tri[triIndex++] = new SimTriangle(topLeftBack, topRightBack, bottomRightBack);
      }
    }

    int frontEdgeStart = rings * (segments + 1);
    int backEdgeStart = faceVerts + (rings * (segments + 1));

    // rim conecting the caps

    for (int segment = 0; segment < segments; segment++) {
      PVector frontLeft = tv[frontEdgeStart + segment];
      PVector frontRight = tv[frontEdgeStart + segment + 1];
      PVector backLeft = tv[backEdgeStart + segment];
      PVector backRight = tv[backEdgeStart + segment + 1];

      tri[triIndex++] = new SimTriangle(frontLeft, backLeft, backRight);
      tri[triIndex++] = new SimTriangle(frontLeft, backRight, frontRight);
    }

    return tri;
  }

  SimExtents getTransformedExtents() {
    return new SimExtents(transformVertices(vertices));
  }

  void drawMe() {
    pushStyle();
    fill(fillColour);
    noStroke();

    PVector[] tv = vertices;
    int faceVerts = (rings + 1) * (segments + 1);

    beginShape(QUADS);

    for (int ring = 0; ring < rings; ring++) {
      for (int segment = 0; segment < segments; segment++) {

        int frontIndexCurrent = ring * (segments + 1) + segment;
        int frontIndexNext = (ring + 1) * (segments + 1) + segment;

        int backIndexCurrent = faceVerts + frontIndexCurrent;
        int backIndexNext = faceVerts + frontIndexNext;

        // front quad
        drawTransformedVertex(tv[frontIndexCurrent]);
        drawTransformedVertex(tv[frontIndexCurrent + 1]);
        drawTransformedVertex(tv[frontIndexNext + 1]);
        drawTransformedVertex(tv[frontIndexNext]);

        // back quad
        drawTransformedVertex(tv[backIndexCurrent]);
        drawTransformedVertex(tv[backIndexNext]);
        drawTransformedVertex(tv[backIndexNext + 1]);
        drawTransformedVertex(tv[backIndexCurrent + 1]);
      }
    }

    int frontEdgeStart = rings * (segments + 1);
    int backEdgeStart = faceVerts + (rings * (segments + 1));

    // rim
    for (int segment = 0; segment < segments; segment++) {
      drawTransformedVertex(tv[frontEdgeStart + segment]);
      drawTransformedVertex(tv[frontEdgeStart + segment + 1]);
      drawTransformedVertex(tv[backEdgeStart + segment + 1]);
      drawTransformedVertex(tv[backEdgeStart + segment]);
    }

    endShape();
    popStyle();
  }
}
