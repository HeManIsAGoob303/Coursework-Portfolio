SimPrism prism;
SimLens lens;
SimSphere backSphere;
SimUI myUI;
SimCamera cam;

ArrayList<Photon> beam = new ArrayList<Photon>();

ArrayList<Impact> blodges = new ArrayList<Impact>();

color glassBlue = color(150, 200, 255, 200);
float coefficientA_Glass = 1.504;
float coefficientB_Glass = 0.004;

color diamond = color(185, 242, 255, 200);
float coefficientA_Diamond = 2.378;
float coefficientB_Diamond = 0.012;

color water = color(64, 196, 255, 200);
float coefficientA_Water = 1.322;
float coefficientB_Water = 0.003;

float currentA = coefficientA_Glass;
float currentB = coefficientB_Glass;
color currentColour = glassBlue;

float airIOR = 1.0;

boolean upPressed, downPressed, leftPressed, rightPressed, zoomIn, zoomOut;
boolean shootPhoton;

boolean usingLens = false;

float speed = 10.0;
float rotSpeed = 0.02;

void setup() {
  size(1200, 800, P3D);
  surface.setResizable(true);

  prism = new SimPrism(231, 200, 200, glassBlue, 1.5);
  lens = new SimLens(180, 160, 40, glassBlue, 1.5);

  backSphere = new SimSphere(2500);
  backSphere.setTranslation(width / 2, height / 2, -500);
  myUI = new SimUI();

  cam = new SimCamera();
  cam.setMoving(false);
  cam.setViewParameters(PI / 8.0, 1, 100000);
  cam.setHUDArea(0, 0, 200, height);

  myUI.addRadioButton("Prism", 10, 30, "optics");
  myUI.addRadioButton("Lens", 10, 50, "optics");

  myUI.addSlider("Radius", 10, 100);
  myUI.addSlider("Thickness", 10, 120);
  myUI.addSlider("Diameter", 10, 140);

  myUI.addSlider("Width", 10, 160);
  
  myUI.addSimpleButton("Reset", 10, 300);
  

  String[] menuItems = new String[3];

  menuItems[0] = "Glass";
  menuItems[1] = "Diamond";
  menuItems[2] = "Water";

  Menu materialMenu = myUI.addMenu("Material Menu", 10, 200, menuItems);

  materialMenu.showSelectedInTitle(true);
  
  materialMenu.setWidth(200);

  myUI.getWidget("Radius").setVisible(false);
  myUI.getWidget("Thickness").setVisible(false);
  myUI.getWidget("Diameter").setVisible(false);

  myUI.getWidget("Width").setVisible(true);
  

  lens.setTranslation(width / 2, height / 2, -500);

  prism.setTranslation(width / 2, height / 2, -500);
  prism.setRotation(0, 0, PI);
  prism.setScale(2.0);
  cam.setPositionAndLookat(new PVector(width / 2, height / 2, 1000), prism.translate);
}

void draw() {

  PVector target = usingLens ? lens.translate : prism.translate;

  // get direction vectors
  PVector camPos = cam.getPosition().copy();
  PVector forward = cam.getForwardVector().normalize();
  PVector side = forward.cross(cam.cameraUpVector).normalize();
  PVector up = side.cross(forward).normalize();


  float currentDist = camPos.dist(target);

  float currentObjectSize = usingLens ? lens.diameter : 200.0;
  float maxZoomIn = currentObjectSize * 0.8;
  float maxZoomOut = backSphere.radius * 0.8;

  float topLimit = target.y - (currentDist * 0.98);
  float bottomLimit = target.y + (currentDist * 0.98);

  // handle inputs
  if (zoomIn && currentDist > maxZoomIn) camPos.add(PVector.mult(forward, speed));
  if (zoomOut && currentDist < maxZoomOut) camPos.add(PVector.mult(forward, -speed));

  if (upPressed && camPos.y > topLimit) camPos.add(PVector.mult(up, speed));
  if (downPressed && camPos.y < bottomLimit) camPos.add(PVector.mult(up, -speed));

  if (leftPressed) camPos.add(PVector.mult(side, speed));
  if (rightPressed) camPos.add(PVector.mult(side, -speed));

  cam.setPositionAndLookat(camPos, target);

  PVector trueForward = cam.getForwardVector().normalize();

  if (shootPhoton) {
    shootPhoton = false;
    beam.clear();

    for (float wl = 400.0; wl <= 700.0; wl += 30) {
      beam.add(new Photon(camPos, trueForward, wl));
    }
  }

  for (Photon p : beam) {
    if (p.speed <= 0) continue;

    boolean handled = false;

    SimRay ray = new SimRay(p.pos, p.dir);
    ray.clearIntersectingTriangles();
    boolean rayHitsPrism = false;

    SimTriangle[] tris = usingLens ? lens.getTransformedTriangles() : prism.getTransformedTriangles();

    for (SimTriangle tri : tris) {
      if (ray.addIntersectingTriangle(tri)) {
        rayHitsPrism = true;
      }
    }

    if (rayHitsPrism) {

      PVector impactPoint = ray.getNearestTriangleIntersectionPoint();
      PVector surfaceNormal;

      if (usingLens) {
        PVector centre = p.hasHitObject ? lens.backCentre.copy() : lens.frontCentre.copy();
        surfaceNormal = PVector.sub(impactPoint, centre).normalize();

        if (lens.radiusOfCurvature < 0) {
          surfaceNormal.mult(-1);
        }
      } else {
        surfaceNormal = ray.getIntersectionNormal().copy().normalize();
      }

      if (PVector.dot(p.dir, surfaceNormal) > 0) {
        surfaceNormal.mult(-1);
      }

      float distance = p.pos.dist(impactPoint);

      if (distance <= p.speed) {
        p.pos = impactPoint.copy();

        if (!p.hasHitObject) {
          p.whiteLight.add(p.pos.copy());
          p.trail.add(p.pos.copy());
          p.hasHitObject = true;
        } else {
          p.trail.add(p.pos.copy());
          p.hasExitedPrism = true;
        }

        float A = currentA;
        float B = currentB;

        float prismIOR = calculateIORByWavelength(A, B, p.wavelength);

        if (p.hasExitedPrism) {
          p.refract(surfaceNormal, prismIOR, airIOR);
        } else {
          p.refract(surfaceNormal, airIOR, prismIOR);
        }


        float epsilon = 5.0;
        p.pos.add(PVector.mult(p.dir, epsilon));
        handled = true;
      }
    }

    if (!handled && p.hasExitedPrism) {
      PVector sphereCen = backSphere.getTransformedCentre();
      PVector oc = PVector.sub(p.pos, sphereCen);
      float b = PVector.dot(p.dir, oc); //
      float c = PVector.dot(oc, oc) - (backSphere.getTransformedRadius() * backSphere.getTransformedRadius()); // Vector form formula for a sphere
      float discr = b * b - c; // Discriminant

      if (discr >= 0) {
        float t = -b + sqrt(discr); //

        if (t > 0) {
          PVector hitPoint = PVector.add(p.pos, PVector.mult(p.dir, t));
          p.pos = hitPoint.copy();
          p.trail.add(p.pos.copy());
          blodges.add(new Impact(p.pos, p.c));
          p.speed = 0;
          handled = true;
        }
      }
    }


    if (!handled) {
      p.update();
    }
  }

  background(10);
  lights();
  cam.update();

  pushStyle();
  noStroke();
  fill(30, 40, 50);
  backSphere.drawMe();
  popStyle();

  pushStyle();
  noStroke();
  hint(DISABLE_DEPTH_MASK);
  if (usingLens) lens.drawMe();
  else           prism.drawMe();
  hint(ENABLE_DEPTH_MASK);
  popStyle();

  for (Impact b : blodges) {
    b.drawMe();
  }

  blendMode(ADD);

  for (Photon p : beam) {
    p.render();
  }

  blendMode(BLEND);

  hint(DISABLE_DEPTH_TEST);
  cam.startDraw2D();
  myUI.update();
  cam.endDraw2D();
  hint(ENABLE_DEPTH_TEST);
}

void handleSimUIEvent(SimUIEvent e) {
  if (e.radioGroupName.equals("optics")) {
    if (e.uiLabel.equals("Prism")) {
      usingLens = false;
    }
    if (e.uiLabel.equals("Lens")) {
      usingLens = true;
    }

    myUI.getWidget("Radius").setVisible(usingLens);
    myUI.getWidget("Thickness").setVisible(usingLens);
    myUI.getWidget("Diameter").setVisible(usingLens);

    myUI.getWidget("Width").setVisible(!usingLens);


    beam.clear();
    blodges.clear();
    PVector target = usingLens ? lens.translate : prism.translate;
    cam.setPositionAndLookat(cam.getPosition(), target);
  }

  if (e.uiLabel.equals("Radius")) {
    float curvature = map(e.sliderValue, 0, 1, -0.008, 0.008);
    if (abs(curvature) < 0.0001) curvature = 0.0001;

    lens.radiusOfCurvature = 1.0 / curvature;
    lens.buildGeometry();
    beam.clear();
    blodges.clear();
  }

  if (e.uiLabel.equals("Thickness")) {
    lens.thickness = map(e.sliderValue, 0, 1, 10, 200);
    lens.buildGeometry();
    beam.clear();
  }

  if (e.uiLabel.equals("Diameter")) {
    lens.diameter = map(e.sliderValue, 0, 1, 50, 400);
    lens.buildGeometry();
    beam.clear();
  }

  if (e.uiLabel.equals("Width")) {
    float w = map(e.sliderValue, 0, 1, 100, 300);
    prism.setDimensions(w, 200, 200);
    beam.clear();
  }

  if (e.uiLabel.equals("Material Menu")) {
    String chosenMaterial = e.menuItem;

    if ("Glass".equals(chosenMaterial)) {
      currentA = coefficientA_Glass;
      currentB = coefficientB_Glass;
      currentColour = glassBlue;
    } else if ("Diamond".equals(chosenMaterial)) {
      currentA = coefficientA_Diamond;
      currentB = coefficientB_Diamond;
      currentColour = diamond;
    } else if ("Water".equals(chosenMaterial)) {
      currentA = coefficientA_Water;
      currentB = coefficientB_Water;
      currentColour = water;
    }

    lens.fillColour = currentColour;
    prism.setFillColour(currentColour);

    beam.clear();
  }
  
  if (e.uiLabel.equals("Reset")) {
    beam.clear();
    blodges.clear();
    cam.setPositionAndLookat(new PVector(width / 2, height / 2, 1000), (usingLens) ? lens.translate : prism.translate);
  }
  
  
}

void keyPressed() {

  if (key == 'w' || key == 'W') {
    upPressed = true;
  } else if (key == 's' || key == 'S') {
    downPressed = true;
  } else if (key == 'a' || key == 'A') {
    leftPressed = true;
  } else if (key == 'd' || key == 'D') {
    rightPressed = true;
  }

  if (key == CODED) {
    if (keyCode == UP) {
      zoomIn = true;
    }
    if (keyCode == DOWN) {
      zoomOut = true;
    }
  }

  if (!upPressed && !downPressed && !leftPressed && !rightPressed) {
    if (key == ' ') {
      shootPhoton = true;
    }
  }
}

void keyReleased() {

  if (key == 'w' || key == 'W') {
    upPressed = false;
  } else if (key == 's' || key == 'S') {
    downPressed = false;
  } else if (key == 'a' || key == 'A') {
    leftPressed = false;
  } else if (key == 'd' || key == 'D') {
    rightPressed = false;
  }

  if (key == CODED) {
    if (keyCode == UP) {
      zoomIn = false;
    }
    if (keyCode == DOWN) {
      zoomOut = false;
    }
  }
}
